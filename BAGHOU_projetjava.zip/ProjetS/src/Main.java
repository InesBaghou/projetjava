import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.Scanner;
import java.util.Set;
import java.util.Stack;
import java.sql.Statement;



public class Main {

	private static Scanner choix;

	public static void main(String[] args) {
		
		String url = "jdbc:mysql://localhost/projet";
        String user = "root";
        String password = "";
        
        //Connexion a la bdd      
        try {
        	Class.forName("com.mysql.jdbc.Driver").newInstance();
            System.out.println("Driver O.K.");
            Connection conn = DriverManager.getConnection(url, user, password);
            System.out.println("Connexion effective !"); 
             
          } catch (Exception e) {
            e.printStackTrace();
          }
		
        boolean boucle = true;
        while(boucle==true) {
        	
        	System.out.println("Bienvenu dans la Base, que voulez vous faire ? "
    				+ "\n 0 - Quitter le programme"
    				+ "\n 1- Rechercher un patient"
    				+ "\n 2- Afficher la liste des patients hospitalises plus d'une semaine"
    				+ "\n 3- Afficher les informations d'une hospitalisation");
            
    		choix = new Scanner(System.in);
    		int num=choix.nextInt();
    		
    		switch(num) {
    		case 0: System.exit(0);
    				break;
    		case 1: System.out.println("Recherche de patient "
    				+ "\n Vous pouvez rechercher un patient via son nom (1) ou son numero patient (2)");
    				Scanner choix2 = new Scanner(System.in);
    				int num2=choix2.nextInt();
    				if(num2==1) {
    					System.out.println("Entrez le nom du patient");
    					Scanner nom = new Scanner(System.in);
    					String nomP = nom.nextLine();
    					DAO<Patient> p = new PatientDAO(SdzConnection.getInstance());
    					Patient pat = p.findByString(nomP);
    					System.out.println("Le patient recherche est "+ pat.getNomPatient() +  "  son prenom est  " + pat.getPrenomPatient() + "  et son numero patient est  " + pat.getNumPatient());
    					break;
    				}
    				if(num2==2) {
    					System.out.println("Entrez le numero du patient");
    					Scanner numero = new Scanner(System.in);
    					int numP = numero.nextInt();
    					DAO<Patient> p = new PatientDAO(SdzConnection.getInstance());
    					Patient pat = p.find(numP);
    					System.out.println("Le nom du patient recherche est "+ pat.getNomPatient() +  "  son prenom est  " + pat.getPrenomPatient() +  " et  son numero patient est  " + pat.getNumPatient());
    					//DAO<Hospitalisation> hospit = new HospitalisationDAO(SdzConnection.getInstance());
    					//int hosp = hospit.count(numP);
    					//System.out.println("Ce patient a ete hospitalise "+numP+" fois dans cet hopital");
    					break;
    				}
    				else {
    					System.out.println("Cette option n'existe pas ");
    				}
    					break;				    			
    		case 2: System.out.println("Les patients hospitalises ayant ete hospitalise plus d'une semaines sont:");	
    			try{
	            Connection con = DriverManager.getConnection(url, user, password);
	            java.sql.Statement stt = con.createStatement();
	            ResultSet res = stt.executeQuery("SELECT DISTINCT Nom, Prenom "
	            		+ "FROM  tab_hospitalisation as TH, tab_patient as TP "
	            		+ "WHERE TP.NumPatient=TH.NumPatient "
	            		+ "AND (TH.DateSortie - TH.DateEntree) < 7;");  
	            while (res.next()){
	                System.out.println("Patient " +res.getString(1) + " " + res.getString(2));
	            }
            }
            catch (Exception e){
                e.printStackTrace();
            }
    			break;
    		
    		case 3: System.out.println("Entrez le numero hospitalisation");
    			Scanner num3 = new Scanner(System.in);
    			int numH = num3.nextInt();
    			try {
    				DAO<Hospitalisation> h = new HospitalisationDAO(SdzConnection.getInstance());
        			Hospitalisation hos = h.find(numH);
        			DAO<Patient>pat2=new PatientDAO(SdzConnection.getInstance());
        			Patient pat = pat2.findPat(numH);
        			DAO<Acte>a= new ActeDAO(SdzConnection.getInstance());
        			Acte acte = a.findActe(numH);
        			System.out.println("Hospitalisation numero "+ hos.getNumHospi()+"  effectue pour le patient numero "+hos.getNumPatient()
        			+"\n Informations Patient \n"
        			+ "Nom : "+pat.getNomPatient() +"   Prenom : "+pat.getPrenomPatient()
        			+"\n Information sejour " 
        			+ "\n Date d'entree le "+hos.getDateIn() + "\n Date de sortie le "+hos.getDateOut()
        			+ "\n Information hospitalisation " 
        			+ "\n Numero de l'acte effectue :  " + acte.getNumActe() + "\n Code CCAM associe: " + acte.codeCCAM());
    			} 
    			catch (Exception e){
                    e.printStackTrace();
                }		
    			break;
    		default: System.out.println("Cette option n'existe pas");	
    		}
    		
    		System.out.println("Appuyer sur 1 pour revenir au menu, appuyer sur 2 sinon");
    		Scanner continuer = new Scanner(System.in);
			int con = continuer.nextInt();
    		if(con==2) {
    			boucle=false;
    		}
		
		System.out.println("fin du programme");		
		}

	}
}


