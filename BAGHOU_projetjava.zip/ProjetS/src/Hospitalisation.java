import java.sql.Date;
import java.util.ArrayList;

public class Hospitalisation {
	public int NumPatient;
	public int NumHospi;
	public Date dateIn;
	public Date dateOut;
	
	/**
	 * Constructeurs
	 */
	public Hospitalisation(int numPatient, int numHospi, Date dateIn, Date dateOut) { 
		super();
		this.NumPatient = numPatient;
		this.NumHospi = numHospi;
		this.dateIn = dateIn;
		this.dateOut = dateOut;
		
		
	}
	public Hospitalisation() {
		
	}



	/**
	 * Getters
	 */
	public int getNumPatient() {
		return NumPatient;
	}
	

	public int getNumHospi() {
		return NumHospi;
	}
	
	public Date getDateIn() {
		return dateIn;
	}
	
	public Date getDateOut() {
		return dateOut;
	}
	

	/**
	 * Setters
	 */
	
	public void setNumPatient(int numPatient) {
		this.NumPatient = numPatient;
	}

	public void setNumHospi(int numHospi) {
		this.NumHospi = numHospi;
	}
	
	public void setDateIn(Date dateIn) {
		this.dateIn = dateIn;
	}
	public void setDateOut(Date dateOut) {
		this.dateOut = dateOut;
	}
	
	

}
