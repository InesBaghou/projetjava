
public class Acte {
	public int numActe;
	public int numHospitalisation;
	public String codeCCAM;
	
	/**
	 * Constructeurs
	 */
	public Acte() {
		
	}
	
	public Acte(int numActe, int numHospitalisation, String codeCCAM) {
		super();
		this.numActe = numActe;
		this.numHospitalisation = numHospitalisation;
		this.codeCCAM = codeCCAM;
		
	}

	/**
	 * Getters
	 */
	public int getNumActe() {
		return numActe;
	}
	
	public int getNumHospitalisation() {
		return numHospitalisation;
	}
	
	public String codeCCAM() {
		return codeCCAM;
	}

	/**
	 * Setters
	 */
	public void setNumActe(int numActe) {
		this.numActe = numActe;
	}

	public void setNumHospitalisation(int numHospitalisation) {
		this.numHospitalisation = numHospitalisation;
	}
	
	public void setCodeCCAM(String codeCCAM) {
		this.codeCCAM=codeCCAM;
	}
	
	

}
