import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PatientDAO extends DAO<Patient> {
	public PatientDAO(Connection conn) {
		super(conn);
	}

	
	public Patient find(int num) {
		Patient patient = new Patient();	
		try {
		      ResultSet result = this.connect.createStatement(
		        ResultSet.TYPE_SCROLL_INSENSITIVE,
		        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * "
		        		+ "FROM tab_patient "
		        		+ "WHERE numPatient = " + num);
		      if(result.first())
		        patient = new Patient(result.getString("Nom"), result.getString("Prenom"), num); 
		    } catch (SQLException e) {
		      e.printStackTrace();
		    }
		return patient;
	}
		
		
	public Patient findByString(String nom) {
		Patient patient = new Patient();
		try {
		      ResultSet result = this.connect.createStatement(
		        ResultSet.TYPE_SCROLL_INSENSITIVE,
		        ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * "
		        		+ " FROM tab_patient "
		        		+ " WHERE Nom = " + nom);
		      if(result.first())
		        patient = new Patient(nom, result.getString("Prenom"), result.getInt("NumPatient"));       
		    } catch (SQLException e) {
		      e.printStackTrace();
		    }
		return patient;			
	
	}

	
	
	public Patient findPat(int num) {
		Patient patientHospitalise = null;
		try {
			ResultSet res = this.connect.createStatement(
					ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT p.Nom, p.Prenom, p.NumPatient FROM tab_hospitalisation as h, tab_patient as p WHERE p.NumPatient = h.NumPatient AND NumHospitalisation="+num);
				
				if(res.first())
					patientHospitalise = new Patient(res.getString("Nom"), res.getString("Prenom"), res.getInt("NumPatient"));
				
		}catch (SQLException e) {
		      e.printStackTrace();
		    }
		return patientHospitalise;
	}


	@Override
	public Acte findActe(int numH) {
		// TODO Auto-generated method stub
		return null;
	}


	/**@Override
	public int count(int numP) {
		// TODO Auto-generated method stub
		return (Integer) null;
	}**/



	

}
