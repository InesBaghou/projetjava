import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class SdzConnection {
	
	public static String url = "jdbc:mysql://localhost/projet";
	public static String user = "root";
	public static String passwd = "";
	public static Connection connect;
	  public static Connection getInstance(){
	   
		  if(connect == null){
	      try {
	        connect = DriverManager.getConnection(url, user, passwd);
	        System.out.println("Connexion effective !");
	      } catch (SQLException e) {
	        e.printStackTrace();
	      }
	    }      
	    return connect;
	  }

}
