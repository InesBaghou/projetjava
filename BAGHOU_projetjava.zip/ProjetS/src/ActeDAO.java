import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;


public class ActeDAO extends DAO<Acte>{
	public ActeDAO(Connection conn) {
		super(conn);
	}
	
	public Acte findActe(int numActe) {
		Acte acte = new Acte();
		try {
			ResultSet result = this.connect.createStatement(
					ResultSet.TYPE_SCROLL_INSENSITIVE, 
					ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM tab_acte WHERE NumHopitalisation =" + numActe);
			if(result.first())
				acte = new Acte(numActe, result.getInt("NumHopitalisation"), result.getString("codeCCAM"));
		}
		catch (SQLException e) {
		      e.printStackTrace();
		    }
		return acte;
	}
	

	@Override
	public Acte find(int num) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Acte findByString(String nom) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Patient findPat(int numH) {
		// TODO Auto-generated method stub
		return null;
	}

	/**@Override
	public int count(int numP) {
		// TODO Auto-generated method stub
		return (Integer) null;
	}**/


	

}
