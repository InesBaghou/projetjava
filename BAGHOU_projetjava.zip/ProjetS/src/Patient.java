import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.Iterator;


public class Patient {
	public int numPatient;
	public String nomPatient;
	public String prenomPatient;
	

	/**
	 * Constructeurs
	 */
	public Patient(int numPatient) {
		super();
		this.numPatient = numPatient;
	}
	
	public Patient() {
		
	}
	
	public Patient(String nomPatient) {
		super();
		this.nomPatient = nomPatient;
	}
	
	public Patient(String nomPatient, String prenomPatient, int numPatient) {
		super();
		this.nomPatient = nomPatient;
		this.prenomPatient = prenomPatient;
		this.numPatient = numPatient;
	}
		
	

	/**
	 * Getters
	 */
	public int getNumPatient() {
		return numPatient;
	}
	
	public String getNomPatient() {
		return nomPatient;
	}
	
	public String getPrenomPatient() {
		return prenomPatient;
	}
	
	
	/**
	 * Setters
	 */
	public void setNumPatient(int numPatient) {
		this.numPatient = numPatient;
	}
	
	public void setNomPatient(String nomPatient) {
		this.nomPatient = nomPatient;
	}
	
	public void setPrenomPatient(String prenomPatient) {
		this.prenomPatient = prenomPatient;
	}
	
	

}
