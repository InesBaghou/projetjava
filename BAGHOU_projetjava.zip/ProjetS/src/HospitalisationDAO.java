import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;


public class HospitalisationDAO extends DAO<Hospitalisation>{
	
	public HospitalisationDAO(Connection conn) {
		super(conn);
	}

	@Override
	public Hospitalisation find(int num) {
		Hospitalisation hospi = new Hospitalisation();
		try {
			ResultSet res = this.connect.createStatement(
					ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT * FROM tab_hospitalisation WHERE NumHospitalisation ="+num);
				if(res.first())
					hospi = new Hospitalisation(res.getInt("NumPatient"), num, res.getDate("DateEntree"), res.getDate("DateSortie"));
				
		}catch (SQLException e) {
		      e.printStackTrace();
		    }
		return hospi;
	}
	
	public int count(int num) {
		
		try {
			ResultSet res = this.connect.createStatement(
					ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY).executeQuery("SELECT COUNT(h.NumPatient) FROM tab_patient as p, tab_hospitalisationas h, WHERE h.numPatient = p.numPatient AND NumPatient ="+num);
		num = res.getInt(1);			
			
		}catch (SQLException e) {
		      e.printStackTrace();
		    }
		return num;
	}
	
	
	
	
	
	
	

	@Override
	public Hospitalisation findByString(String nom) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Patient findPat(int numH) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Acte findActe(int numH) {
		// TODO Auto-generated method stub
		return null;
	}



	
}
