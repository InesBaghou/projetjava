import java.sql.Connection;



public abstract class DAO <T>{
	protected Connection connect = null;
	   
	  public DAO(Connection conn){
	    this.connect = conn;
	  }
	  
	  public abstract T find(int num);
	  
	  public abstract T findByString(String nom);

	  public abstract Patient findPat(int numH);
	
	  public abstract Acte findActe(int numH);

	  //public abstract int count(int numP);

	}
	  


